/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.event.interaction;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1934;
import net.minecraft.class_3222;

@Mixin(class_3222.class)
public class ServerPlayerMixin {
	@Inject(method = "attack", at = @At("HEAD"), cancellable = true)
	public void onPlayerInteractEntity(class_1297 target, CallbackInfo info) {
		class_3222 player = (class_3222) (Object) this;
		class_1269 result = AttackEntityCallback.EVENT.invoker().interact(player, player.method_51469(), class_1268.field_5808, target, null);

		if (result != class_1269.field_5811) {
			info.cancel();
		}
	}

	@Inject(method = "calculateGameModeForNewPlayer", at = @At("HEAD"), cancellable = true)
	public void fakePlayerGameMode(class_1934 backupGameMode, CallbackInfoReturnable<class_1934> cir) {
		// Set the default game mode of the fake player to survival, regardless of the servers forced game mode.
		if ((Object) this instanceof FakePlayer) {
			cir.setReturnValue(class_1934.field_9215);
		}
	}
}
