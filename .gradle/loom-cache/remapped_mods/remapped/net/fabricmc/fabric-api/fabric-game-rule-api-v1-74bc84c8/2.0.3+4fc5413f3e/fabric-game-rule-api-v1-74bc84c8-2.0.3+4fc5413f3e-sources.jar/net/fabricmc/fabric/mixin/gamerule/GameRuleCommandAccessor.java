/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.gamerule;

import net.minecraft.class_12279;
import net.minecraft.class_2168;
import net.minecraft.class_3065;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_3065.class)
public interface GameRuleCommandAccessor {
	@Invoker("queryRule")
	static <T> int invokeExecuteQuery(class_2168 serverCommandSource, class_12279<T> ruleKey) {
		throw new AssertionError("This shouldn't happen!");
	}
}
