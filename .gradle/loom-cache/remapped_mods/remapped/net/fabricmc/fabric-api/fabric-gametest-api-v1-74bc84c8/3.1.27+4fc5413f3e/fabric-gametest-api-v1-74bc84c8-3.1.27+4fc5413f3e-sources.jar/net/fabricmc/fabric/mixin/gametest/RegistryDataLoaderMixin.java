/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.gametest;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.impl.gametest.FabricGameTestModInitializer;
import net.minecraft.class_3300;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import net.minecraft.class_7655;
import net.minecraft.class_7924;

@Mixin(class_7655.class)
public class RegistryDataLoaderMixin {
	@Unique
	private static final AtomicBoolean LOADING_DYNAMIC_REGISTRIES = new AtomicBoolean(false);

	@Inject(method = "load(Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen;", at = @At("HEAD"))
	private static void loadFromResources(class_3300 resourceManager, List<class_7225.class_7226<?>> registries, List<class_7655.class_7657<?>> entries, CallbackInfoReturnable<class_5455.class_6890> cir) {
		LOADING_DYNAMIC_REGISTRIES.set(entries.stream().anyMatch(entry -> entry.comp_985() == class_7924.field_56161));
	}

	@Inject(
			method = "load(Lnet/minecraft/resources/RegistryDataLoader$LoadingFunction;Ljava/util/List;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen;",
			at = @At(
					value = "INVOKE",
					target = "Ljava/util/List;forEach(Ljava/util/function/Consumer;)V",
					ordinal = 1
			)
	)
	private static void beforeFreeze(@Coerce Object loadable, List<class_7225.class_7226<?>> wrappers, List<class_7655.class_7657<?>> entries, CallbackInfoReturnable<class_5455.class_6890> cir, @Local(ordinal = 2) List<class_7655.class_9158<?>> registriesList) {
		if (LOADING_DYNAMIC_REGISTRIES.getAndSet(false)) {
			FabricGameTestModInitializer.registerDynamicEntries(registriesList);
		}
	}
}
