/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.networking.splitter;

import java.util.List;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.MessageToMessageDecoder;
import org.jspecify.annotations.Nullable;
import net.fabricmc.fabric.impl.networking.GenericPayloadAccessor;
import net.fabricmc.fabric.impl.networking.PayloadTypeRegistryImpl;
import net.fabricmc.fabric.impl.networking.VanillaPacketTypes;
import net.fabricmc.fabric.mixin.networking.accessor.PacketDecoderAccessor;
import net.minecraft.class_2543;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import net.minecraft.class_8703;
import net.minecraft.class_8710;
import net.minecraft.class_9145;

public class FabricPacketMerger extends MessageToMessageDecoder<class_2596<?>> {
	private final class_2543<?> decoderHandler;
	private final PayloadTypeRegistryImpl<?> payloadTypeRegistry;
	private final VanillaPacketTypes vanillaPacketTypes;
	@Nullable
	private Merger packetMerger;

	public FabricPacketMerger(class_2543<?> decoderHandler, PayloadTypeRegistryImpl<?> payloadTypeRegistry, VanillaPacketTypes vanillaPacketTypes) {
		this.decoderHandler = decoderHandler;
		this.payloadTypeRegistry = payloadTypeRegistry;
		this.vanillaPacketTypes = vanillaPacketTypes;
	}

	protected void decode(ChannelHandlerContext channelHandlerContext, class_2596<?> packet, List<Object> list) throws Exception {
		if (this.packetMerger != null) {
			ensureNotTransitioning(packet);

			class_8710 payload = packet instanceof GenericPayloadAccessor accessor ? accessor.fabric_payload() : null;

			if (payload == null) {
				throw new DecoderException("Received '" + packet.method_65080().comp_2231() + "' packet, while expecting 'minecraft:custom_payload'!");
			}

			if (!(payload instanceof FabricSplitPacketPayload splitPacketPayload)) {
				throw new DecoderException("Expected '" + FabricSplitPacketPayload.ID.comp_2242() +"' payload packet, but received '" + payload.method_56479().comp_2242() + "'!");
			}

			if (this.packetMerger.add(channelHandlerContext, splitPacketPayload, list)) {
				this.packetMerger = null;
			}
		} else if (packet instanceof GenericPayloadAccessor accessor && accessor.fabric_payload() instanceof FabricSplitPacketPayload payload) {
			ensureNotTransitioning(packet);
			ByteBuf buf = payload.byteBuf();
			int packetSize = class_8703.method_53016(buf);
			int readerIndex = buf.readerIndex();

			class_9145<?> packetType = this.vanillaPacketTypes.get(class_8703.method_53016(buf));

			if (packetType != packet.method_65080()) {
				throw new DecoderException("Received unsupported split packet type! Expected '" + packet.method_65080().comp_2231() + " got '" + (packetType != null ? packetType.comp_2231() : "<NULL>") + "'!");
			}

			class_2960 payloadId = class_2960.field_48267.decode(payload.byteBuf());

			buf.readerIndex(readerIndex);
			int maxSize = payloadTypeRegistry.getMaxPacketSize(payloadId);

			if (maxSize == -1) {
				throw new DecoderException("Received '" + payloadId + "' packet doesn't support splitting, but received split data!");
			} else if (maxSize < packetSize) {
				throw new DecoderException("Received '" + payloadId + "' packet is larger than max allowed size! Got " + packetSize + " bytes, expected " + maxSize + " bytes!");
			}

			this.packetMerger = new Merger(this.decoderHandler, payloadId, packetSize);

			if (this.packetMerger.add(channelHandlerContext, payload, list)) {
				throw new DecoderException("Received '" + payloadId + "' as a split packet, but it wasn't actually split!");
			}
		} else {
			list.add(packet);

			if (packet.method_55943()) {
				channelHandlerContext.pipeline().remove(channelHandlerContext.name());
			}
		}
	}

	private static void ensureNotTransitioning(class_2596<?> packet) {
		if (packet.method_55943()) {
			throw new DecoderException("Terminal message received in bundle");
		}
	}

	private static class Merger {
		private final PacketDecoderAccessor decoderHandler;
		private final class_2960 packetId;
		private final int finalSize;

		private final ByteBuf byteBuf;

		Merger(class_2543<?> decoderHandler, class_2960 identifier, int finalSize) {
			this.decoderHandler = (PacketDecoderAccessor) decoderHandler;
			this.packetId = identifier;
			this.byteBuf = Unpooled.buffer(finalSize);
			this.finalSize = finalSize;
		}

		boolean add(ChannelHandlerContext channelHandlerContext, FabricSplitPacketPayload payload, List<Object> objects) throws Exception {
			int newSize = this.byteBuf.readableBytes() + payload.byteBuf().readableBytes();

			if (this.finalSize < newSize) {
				throw new DecoderException("Received too much data for packet '" + this.packetId + "'! Expected " + this.finalSize + " bytes, received " + newSize + " bytes!");
			}

			this.byteBuf.writeBytes(payload.byteBuf());

			if (this.byteBuf.readableBytes() == this.finalSize) {
				this.decoderHandler.fabric_decode(channelHandlerContext, byteBuf, objects);
				return true;
			}

			return false;
		}
	}
}
