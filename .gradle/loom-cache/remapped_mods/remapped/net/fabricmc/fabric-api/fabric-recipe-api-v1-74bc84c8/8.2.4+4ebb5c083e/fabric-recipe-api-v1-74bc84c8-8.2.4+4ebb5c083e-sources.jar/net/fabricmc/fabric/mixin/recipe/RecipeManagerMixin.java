/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.recipe;

import java.util.Collection;
import java.util.stream.Stream;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.fabric.api.recipe.v1.FabricServerRecipeManager;
import net.fabricmc.fabric.api.recipe.v1.sync.SynchronizedRecipes;
import net.fabricmc.fabric.impl.recipe.sync.SynchronizedRecipesImpl;
import net.minecraft.class_10289;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1937;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_3956;
import net.minecraft.class_8786;
import net.minecraft.class_9695;

@Mixin(class_1863.class)
public abstract class RecipeManagerMixin implements FabricServerRecipeManager {
	@Shadow
	private class_10289 recipes;
	@Unique
	private SynchronizedRecipes synchronizedRecipes = SynchronizedRecipesImpl.EMPTY;

	@Inject(method = "apply(Lnet/minecraft/world/item/crafting/RecipeMap;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/util/profiling/ProfilerFiller;)V", at = @At("HEAD"))
	private void updateSynchronizedRecipes(class_10289 preparedRecipes, class_3300 resourceManager, class_3695 profiler, CallbackInfo ci) {
		this.synchronizedRecipes = new SynchronizedRecipesImpl(preparedRecipes);
	}

	@Override
	public <I extends class_9695, T extends class_1860<I>> Collection<class_8786<T>> getAllOfType(class_3956<T> type) {
		return this.recipes.method_64698(type);
	}

	@Override
	public <I extends class_9695, T extends class_1860<I>> Stream<class_8786<T>> getAllMatches(class_3956<T> type, I input, class_1937 world) {
		return this.recipes.method_64699(type, input, world);
	}

	@Override
	public SynchronizedRecipes getSynchronizedRecipes() {
		return this.synchronizedRecipes;
	}
}
