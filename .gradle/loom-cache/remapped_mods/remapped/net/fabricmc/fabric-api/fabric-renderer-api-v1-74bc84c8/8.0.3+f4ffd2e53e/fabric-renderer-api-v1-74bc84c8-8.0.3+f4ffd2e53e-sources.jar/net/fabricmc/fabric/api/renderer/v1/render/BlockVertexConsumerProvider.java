/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.renderer.v1.render;

import net.minecraft.class_11515;
import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

/**
 * Like {@link class_4597}, but takes {@link class_11515} instead of {@link class_1921}. Primarily
 * used to correctly render block models which have geometry on more than one layer.
 *
 * @see FabricBlockModelRenderer
 */
public interface BlockVertexConsumerProvider {
	class_4588 getBuffer(class_11515 layer);
}
