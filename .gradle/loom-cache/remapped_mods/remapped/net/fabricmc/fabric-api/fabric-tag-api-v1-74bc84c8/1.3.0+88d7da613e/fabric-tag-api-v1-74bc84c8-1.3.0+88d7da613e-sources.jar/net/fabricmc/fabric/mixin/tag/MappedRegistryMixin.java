/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.tag;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import net.fabricmc.fabric.impl.tag.SimpleRegistryExtension;
import net.fabricmc.fabric.impl.tag.TagAliasEnabledRegistryWrapper;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;

/**
 * Adds tag alias support to {@code SimpleRegistry}, the primary registry implementation.
 *
 * <p>Additionally, the {@link TagAliasEnabledRegistryWrapper} implementation is for dynamic registry tag loading.
 */
@Mixin(class_2370.class)
abstract class MappedRegistryMixin<T> implements SimpleRegistryExtension, TagAliasEnabledRegistryWrapper {
	@Unique
	private static final Logger LOGGER = LoggerFactory.getLogger("fabric-tag-api-v1");

	@Unique
	private Map<class_6862<?>, Set<class_6862<?>>> pendingTagAliasGroups;

	@Shadow
	@Final
	private class_5321<? extends class_2378<T>> key;

	@Shadow
	class_2370.class_10105<T> allTags;

	@Shadow
	protected abstract class_6885.class_6888<T> createTag(class_6862<T> tag);

	@Shadow
	abstract void refreshTagsInHolders();

	@Shadow
	public abstract class_5321<? extends class_2378<T>> key();

	@Override
	public void fabric_loadTagAliases(Map<class_6862<?>, Set<class_6862<?>>> aliasGroups) {
		pendingTagAliasGroups = aliasGroups;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void fabric_applyPendingTagAliases() {
		if (pendingTagAliasGroups == null) return;

		Set<Set<class_6862<?>>> uniqueAliasGroups = Sets.newIdentityHashSet();
		uniqueAliasGroups.addAll(pendingTagAliasGroups.values());

		for (Set<class_6862<?>> aliasGroup : uniqueAliasGroups) {
			Set<class_6880<T>> entries = Sets.newIdentityHashSet();

			// Fetch all entries from each tag.
			for (class_6862<?> tag : aliasGroup) {
				class_6885.class_6888<T> entryList = allTags.method_62698((class_6862<T>) tag).orElse(null);

				if (entryList != null) {
					entries.addAll(entryList.field_36460);
				} else {
					LOGGER.info("[Fabric] Creating a new empty tag {} for unknown tag used in a tag alias group in {}", tag.comp_327(), tag.comp_326().method_29177());
					Map<class_6862<T>, class_6885.class_6888<T>> tagMap = ((MappedRegistryTagSet2Accessor<T>) allTags).fabric_getTagMap();

					if (!(tagMap instanceof HashMap<?, ?>)) {
						// Unfreeze the backing map.
						tagMap = new HashMap<>(tagMap);
						((MappedRegistryTagSet2Accessor<T>) allTags).fabric_setTagMap(tagMap);
					}

					tagMap.put((class_6862<T>) tag, createTag((class_6862<T>) tag));
				}
			}

			List<class_6880<T>> entriesAsList = List.copyOf(entries);

			// Replace the old entry list contents with the merged list.
			for (class_6862<?> tag : aliasGroup) {
				class_6885.class_6888<T> entryList = allTags.method_62698((class_6862<T>) tag).orElseThrow();
				entryList.field_36460 = entriesAsList;
			}
		}

		LOGGER.debug("[Fabric] Loaded {} tag alias groups for {}", uniqueAliasGroups.size(), key.method_29177());
		pendingTagAliasGroups = null;
	}

	@Override
	public void fabric_refreshTags() {
		refreshTagsInHolders();
	}
}
