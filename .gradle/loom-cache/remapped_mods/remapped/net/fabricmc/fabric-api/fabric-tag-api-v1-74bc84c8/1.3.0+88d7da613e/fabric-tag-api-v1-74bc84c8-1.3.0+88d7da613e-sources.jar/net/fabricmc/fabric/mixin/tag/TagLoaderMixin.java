/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.tag;

import java.util.List;
import java.util.Map;
import java.util.SequencedSet;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.impl.tag.TagRemovalInternals;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3497;
import net.minecraft.class_3503;
import net.minecraft.class_7475;
import net.minecraft.class_8523;

@Mixin(class_3503.class)
public class TagLoaderMixin {
	@Inject(method = "load", at = @At(value = "INVOKE", target = "Ljava/util/List;forEach(Ljava/util/function/Consumer;)V", shift = At.Shift.AFTER))
	private void loadRemoveEntries(class_3300 resourceManager, CallbackInfoReturnable<Map<class_2960, List<class_3503.class_5145>>> cir, @Local(ordinal = 0) class_2960 id, @Local class_7475 parsedContents, @Local String sourceId) {
		class_2960 normalizedId = TagRemovalInternals.normalizeTagResourceId(id);

		for (class_3497 entry : parsedContents.remove()) {
			class_3503.class_5145 entryWithSource = new class_3503.class_5145(entry, sourceId);
			TagRemovalInternals.addRemoveEntry(normalizedId, entryWithSource);
		}

		TagRemovalInternals.addTagSource(normalizedId, sourceId);
	}

	@WrapOperation(method = "build", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/DependencySorter;orderByDependencies(Ljava/util/function/BiConsumer;)V"))
	private void scopeIdAroundOrderByDependencies(class_8523<class_2960, class_3503.class_8522> sorter, BiConsumer<class_2960, class_3503.class_8522> consumer, Operation<Void> original) {
		original.call(sorter, (BiConsumer<class_2960, class_3503.class_8522>) (id, contents) -> {
			TagRemovalInternals.setTagId(id);

			try {
				consumer.accept(id, contents);
			} finally {
				TagRemovalInternals.clearTagId();
			}
		});
	}

	@ModifyArg(method = "build", at = @At(value = "INVOKE", target = "Ljava/util/Map;forEach(Ljava/util/function/BiConsumer;)V"))
	private static BiConsumer<class_2960, List<class_3503.class_5145>> addTagRemovalReferencesToDependencySorter(BiConsumer<class_2960, List<class_3503.class_5145>> forEach) {
		return (id, entries) -> {
			TagRemovalInternals.mergeAddedAndRemovedEntries(id, entries);
			forEach.accept(id, entries);
		};
	}

	@WrapOperation(method = "tryBuildTag", at = @At(value = "INVOKE", target = "Lnet/minecraft/tags/TagEntry;build(Lnet/minecraft/tags/TagEntry$Lookup;Ljava/util/function/Consumer;)Z"))
	private <T> boolean removeEntriesFromTags(class_3497 instance, class_3497.class_7474<T> lookup, Consumer<T> output, Operation<Boolean> original, @Local SequencedSet<T> values, @Local class_3503.class_5145 entry) {
		if (TagRemovalInternals.isEntryRemove(entry)) {
			instance.method_26790(lookup, values::remove);
			return true;
		}

		return original.call(instance, lookup, output);
	}

	@Inject(method = "build", at = @At("RETURN"))
	private <T> void removeTagRemovalReferencesWhenFinished(Map<class_2960, List<class_3503.class_5145>> builders, CallbackInfoReturnable<Map<class_2960, List<T>>> cir) {
		TagRemovalInternals.removeTagRemovalReferences();
	}
}
